package br.edu.ifsp.produto;

public interface IContabil {
   public void CreditarValor();
   public void debitarValor();
}
