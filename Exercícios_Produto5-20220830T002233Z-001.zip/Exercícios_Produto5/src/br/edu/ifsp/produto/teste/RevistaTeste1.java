package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Musica1;
import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.produto.Revista1;
import br.edu.ifsp.utilitario.Data3;

public class RevistaTeste1 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto1 revista1 = Produto1.criaProduto("prod1","Revista",dataCriacao);
		System.out.println(revista1);
		System.out.println(revista1.valorImposto());
		System.out.println(((Revista1) revista1).getIndice());
	    Revista1 revista = (Revista1) revista1;
		System.out.println(((Revista1) revista).getIndice());
		revista.CreditarValor();
	}
}