package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Livro1;
import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.utilitario.Data3;

public class LivroTeste1 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto1 livro1 = Produto1.criaProduto("livro1", "Livro", dataCriacao);
		System.out.println(livro1);
		System.out.println(livro1.valorImposto());
		System.out.println(livro1.quantidadeEstoque());
		System.out.println(((Livro1) livro1).getEscritor());
	    Livro1 livro = (Livro1) livro1;
	    livro.setEscritor("Estritor livro");
		System.out.println(((Livro1) livro1).getEscritor());
	}
}
