package br.edu.ifsp.produto;

import br.edu.ifsp.utilitario.Data2;

public class Produto2 {
	private String codigo;
	private String tipoProduto;
	private Data2 dataCriacao;

	public Produto2(String codigo, String tipoProduto, Data2 dataCriacao) {
		this.codigo = codigo;
		this.tipoProduto = tipoProduto;
		this.dataCriacao = dataCriacao;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public Data2 getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Data2 dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		return this.getCodigo() + " " + this.getTipoProduto() + " " + this.getDataCriacao();
	}
	

}
