package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Produto2;
import br.edu.ifsp.utilitario.Data2;

public class ProdutoTeste2 {
	public static void main(String[] args) {
		Data2 dataCriacao = new Data2(1,1,2022);
		Produto2 produto2 = new Produto2("prod1","Musica",dataCriacao);
		System.out.println(produto2);
	}
}
