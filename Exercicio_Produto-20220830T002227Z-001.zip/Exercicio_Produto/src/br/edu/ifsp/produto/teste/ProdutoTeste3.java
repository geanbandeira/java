package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Produto3;
import br.edu.ifsp.utilitario.Data3;

public class ProdutoTeste3 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto3 produto3 = new Produto3("prod1","Musica",dataCriacao);
		System.out.println(produto3);
	}
}
