package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.utilitario.Data1;

public class ProdutoTeste1 {

	public static void main(String[] args) {
		Data1 dataCriacao = new Data1(1,1,2022);
		Produto1 produto1 = new Produto1("prod1","Musica",dataCriacao);
		System.out.println(produto1);

	}

}
