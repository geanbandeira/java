package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Musica1;
import br.edu.ifsp.produto.Produto4;
import br.edu.ifsp.utilitario.Data3;

public class MusicaTeste1 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto4 musica1 = new Musica1("prod1","Musica",dataCriacao);
		System.out.println(musica1);
		System.out.println(musica1.valorImposto());
	}
}
