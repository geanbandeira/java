package br.edu.ifsp.produto.teste;

import java.util.HashSet;
import java.util.Set;

import br.edu.ifsp.produto.Livro1;
import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.utilitario.Data3;

public class LivroTeste1 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto1 livro1 = Produto1.criaProduto("livro1", "Livro", dataCriacao);
		Produto1 livro2 = Produto1.criaProduto("livro2", "Livro", dataCriacao);
		Produto1 livro3 = Produto1.criaProduto("livro3", "Livro", dataCriacao);
		Produto1 livro4 = Produto1.criaProduto("livro4", "Livro", dataCriacao);
		Produto1 livro5 = Produto1.criaProduto("livro5", "Livro", dataCriacao);
		Produto1 livro6 = Produto1.criaProduto("livro5", "Livro", dataCriacao);
		Set<Produto1> livros = new HashSet<Produto1>();
		livros.add(livro1);
		livros.add(livro2);
		livros.add(livro3);
		livros.add(livro4);
		livros.add(livro5);
		livros.add(livro6);
		for (Produto1 livro : livros) {
			System.out.println(livro);
		}
		
		
		
	}
}
