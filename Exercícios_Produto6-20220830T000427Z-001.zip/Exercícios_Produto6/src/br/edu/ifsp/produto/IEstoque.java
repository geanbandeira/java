package br.edu.ifsp.produto;

public interface IEstoque {
   public double valorEstoque();
   public int quantidadeEstoque();
}
