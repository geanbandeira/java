package br.edu.ifsp.produto;

import br.edu.ifsp.utilitario.Data3;

public abstract class Produto1 implements IContabil, IEstoque{
	private String codigo;
	private String tipoProduto;
	private Data3 dataCriacao;
	
	public static final Produto1 criaProduto(String codigo, String tipoProduto, Data3 dataCriacao) {
		if (tipoProduto.equals("Livro")){
		    return new Livro1(codigo,tipoProduto,new Data3(1,1,2000));		
		}
		if (tipoProduto.equals("Musica")){
		    return new Musica1(codigo,tipoProduto,new Data3(1,1,2000));		
		}
		if (tipoProduto.equals("Revista")){
		    return new Revista1(codigo,tipoProduto,new Data3(1,1,2000));		
		}
		
		throw new RuntimeException("Tipo de produto invalido");
	}

	protected Produto1(String codigo, String tipoProduto, Data3 dataCriacao) {
		this.codigo = codigo;
		this.tipoProduto = tipoProduto;
		this.dataCriacao = dataCriacao;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public Data3 getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Data3 dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		return this.getCodigo() + " " + this.getTipoProduto() + " " + this.getDataCriacao();
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produto1 other = (Produto1) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	public abstract double valorImposto();
}
