package br.edu.ifsp.exercicio.data;

public class DataTeste5 {
  public static void main(String[] args) {
	Data5 data5a = new Data5(10,01,2000);
    System.out.println(data5a.dia);
    System.out.println(data5a.mes);
    System.out.println(data5a.ano);

	Data5 data5b = new Data5(30,11,2000);
    System.out.println(data5b.dia);
    System.out.println(data5b.mes);
    System.out.println(data5b.ano);
	
  }
}
