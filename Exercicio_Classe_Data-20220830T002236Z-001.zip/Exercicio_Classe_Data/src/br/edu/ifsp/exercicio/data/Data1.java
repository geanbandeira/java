package br.edu.ifsp.exercicio.data;

public class Data1 {
   public Data1() {
	   
   }
}
