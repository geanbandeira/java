package br.edu.ifsp.exercicio.data;

public class Data3 {
	int dia;
	int mes;
	int ano;
	
	Data3(int dia, int mes, int ano){
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}

}
