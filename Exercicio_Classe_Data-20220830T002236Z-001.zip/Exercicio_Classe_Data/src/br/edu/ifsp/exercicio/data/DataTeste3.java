package br.edu.ifsp.exercicio.data;

public class DataTeste3 {
  public static void main(String[] args) {
	Data3 data3a = new Data3(10,01,2000);
    System.out.println(data3a.dia);
    System.out.println(data3a.mes);
    System.out.println(data3a.ano);

	Data3 data2b = new Data3(35,15,-2000);
    System.out.println(data2b.dia);
    System.out.println(data2b.mes);
    System.out.println(data2b.ano);

	
  }
}
