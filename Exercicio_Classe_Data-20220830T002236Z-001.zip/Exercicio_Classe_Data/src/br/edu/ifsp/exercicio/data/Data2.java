package br.edu.ifsp.exercicio.data;

public class Data2 {
	int dia;
	int mes;
	int ano;
}
