package br.edu.ifsp.exercicio.data;

public class DataTeste1 {
  public static void main(String[] args) {
	Data1 data1 = new Data1();
	
  }
}
