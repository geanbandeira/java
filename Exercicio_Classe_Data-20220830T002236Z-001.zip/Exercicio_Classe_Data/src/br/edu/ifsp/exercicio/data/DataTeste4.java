package br.edu.ifsp.exercicio.data;

public class DataTeste4 {
  public static void main(String[] args) {
	Data4 data4a = new Data4(10,01,2000);
    System.out.println(data4a.dia);
    System.out.println(data4a.mes);
    System.out.println(data4a.ano);

	Data4 data4b = new Data4(30,2,10);
    System.out.println(data4b.dia);
    System.out.println(data4b.mes);
    System.out.println(data4b.ano);
	
  }
}
