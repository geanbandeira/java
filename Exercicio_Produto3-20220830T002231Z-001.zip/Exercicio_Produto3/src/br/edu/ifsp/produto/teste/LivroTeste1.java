package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Livro1;
import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.utilitario.Data3;

public class LivroTeste1 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto1 livro1 = new Livro1("prod1","Livro",dataCriacao,"escritor1");
		System.out.println(livro1);
		System.out.println(livro1.valorImposto());
		System.out.println(((Livro1) livro1).getEscritor());
	    Livro1 livro = (Livro1) livro1;
		System.out.println(((Livro1) livro1).getEscritor());
		Livro1 livro1a = new Livro1("prod1","Livro",dataCriacao,"escritor1a");
		System.out.println(livro1a.getEscritor());
	}
}
