package br.edu.ifsp.produto;

import br.edu.ifsp.utilitario.Data3;

public class Musica1 extends Produto1{
	private String cantor;
	
	public String getCantor() {
		return cantor;
	}

	public void setCantor(String cantor) {
		this.cantor = cantor;
	}

	public Musica1(String codigo, String tipoProduto, Data3 dataCriacao, String cantor) {
		super(codigo,tipoProduto,dataCriacao);
		this.cantor = cantor;
	}

    @Override	
	public double valorImposto() {
		// calcular imposto
		return 30.00;
	}

}
