package br.edu.ifsp.produto;

import br.edu.ifsp.utilitario.Data3;

public abstract class Produto1 {
	private String codigo;
	private String tipoProduto;
	private Data3 dataCriacao;

	public Produto1(String codigo, String tipoProduto, Data3 dataCriacao) {
		this.codigo = codigo;
		this.tipoProduto = tipoProduto;
		this.dataCriacao = dataCriacao;
	}

	public String getTipoProduto() {
		return tipoProduto;
	}

	public Data3 getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Data3 dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		return this.getCodigo() + " " + this.getTipoProduto() + " " + this.getDataCriacao();
	}
	
	public abstract double valorImposto();
}
