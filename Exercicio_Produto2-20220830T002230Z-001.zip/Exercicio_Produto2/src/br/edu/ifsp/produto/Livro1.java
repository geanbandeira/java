package br.edu.ifsp.produto;

import br.edu.ifsp.utilitario.Data3;

public class Livro1 extends Produto1{
	private String escritor;
	
	public String getEscritor() {
		return escritor;
	}

	public void setEscritor(String escritor) {
		this.escritor = escritor;
	}

	public Livro1(String codigo, String tipoProduto, Data3 dataCriacao,String escritor) {
		super(codigo,tipoProduto,dataCriacao);
		this.escritor = escritor;
	}

    @Override	
	public double valorImposto() {
		// calcular imposto
		return 5.00;
	}

}
