package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.produto.Revista1;
import br.edu.ifsp.utilitario.Data3;

public class RevistaTeste1 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto1 revista1 = new Revista1("prod1","Revista",dataCriacao, "indice da revista");
		System.out.println(revista1);
		System.out.println(revista1.valorImposto());
	}
}