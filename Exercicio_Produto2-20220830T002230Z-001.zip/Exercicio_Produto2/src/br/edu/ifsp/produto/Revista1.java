package br.edu.ifsp.produto;

import br.edu.ifsp.utilitario.Data3;

public class Revista1 extends Produto1{
    private String indice;
        
	public String getIndice() {
		return indice;
	}

	public void setIndice(String indice) {
		this.indice = indice;
	}

	public Revista1(String codigo, String tipoProduto, Data3 dataCriacao, String indice) {
		super(codigo,tipoProduto,dataCriacao);
		this.indice = indice;
	}

    @Override	
	public double valorImposto() {
		// calcular imposto
		return 20.00;
	}

}
