package br.edu.ifsp.produto.teste;

import br.edu.ifsp.produto.Livro1;
import br.edu.ifsp.produto.Musica1;
import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.utilitario.Data3;

public class MusicaTeste1 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		Produto1 musica1 = Produto1.criaProduto("prod1","Musica",dataCriacao);
		System.out.println(musica1);
		System.out.println(musica1.valorImposto());
		System.out.println(((Musica1) musica1).getCantor());
	    Musica1 musica = (Musica1) musica1;
	    musica.setCantor("cantora da musica");

	}
}
