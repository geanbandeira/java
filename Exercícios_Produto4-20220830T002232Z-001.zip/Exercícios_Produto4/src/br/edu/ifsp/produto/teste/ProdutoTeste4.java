package br.edu.ifsp.produto.teste;

//import br.edu.ifsp.produto.Produto1;
import br.edu.ifsp.utilitario.Data3;

public class ProdutoTeste4 {
	public static void main(String[] args) {
		Data3 dataCriacao = new Data3(1,1,2022);
		//Produto1 produto4 = new Produto1("prod1","Musica",dataCriacao);
		//System.out.println(produto4);
		//System.out.println(produto4.valorImposto());
	}
}
